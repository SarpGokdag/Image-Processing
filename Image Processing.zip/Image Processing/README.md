HTML5-webcam-object-tracking-and-stabilizing
============================================

Using HTML &lt;video> and &lt;canvas> to track an object of specific color and display it in a canvas where the object is always centered.
